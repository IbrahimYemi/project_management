<!DOCTYPE html>
<html>

<head>
    <title>Task Notification</title>
</head>

<body>
    <h1>Task Notification</h1>

    <p><?php echo e($taskMessage); ?></p>

    <ul>
        <li><strong>Title:</strong> <?php echo e($task['title'] ?? 'N/A'); ?></li>
        <li><strong>Description:</strong> <?php echo $task['description'] ?? 'No description provided'; ?></li>
        <li><strong>Due Date:</strong>
            <?php echo e(\Carbon\Carbon::parse($task['due_date'])->toFormattedDateString() ?? 'Not set'); ?></li>
        <li><strong>Priority:</strong> <?php echo e($task['priority'] ?? 'N/A'); ?></li>
    </ul>

    <p>
        <a href="<?php echo e($url); ?>"
            style="padding: 10px 15px; background-color: #3490dc; color: white; text-decoration: none; border-radius: 5px;">
            View Task
        </a>
    </p>

    <p>Thanks,<br><?php echo e(config('app.name')); ?></p>
</body>

</html>
<?php /**PATH C:\Users\LENOVO THINKPAD\Desktop\work\projects\project-team-managment\backend\resources\views/emails/task_notification.blade.php ENDPATH**/ ?>