<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            SuperAdminSeeder::class,
            ProjectStatusSeeder::class,
            PriorityStatusSeeder::class,
            // RoleSeeder::class,
            // UserSeeder::class,
            // UserInvitesSeeder::class,
        ]);
    }
}
